![蜡烛](block:betterwithmods:candle)

蜡烛是一个由[动物油脂](../items/tallow.md)和线制成的装饰性方块。 只能被放置在方块的顶端,而不是侧面。*它和[烛台](candle_holders.md)很配哦。*